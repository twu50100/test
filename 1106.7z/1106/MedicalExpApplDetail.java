package tw.com.skl.exp.kernel.model6.bo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import tw.com.skl.common.model6.bo.BaseBo;
import tw.com.skl.common.model6.bo.impl.BaseBoImpl;

/**
 * 醫檢費申請明細
 * 
 * @author Jackson Lee
 * @version 1.0, 2009/3/2
 **/
@Entity()
@Table(name = "TBEXP_MEDICAL_EXP_APPL_DETAIL")
public class MedicalExpApplDetail extends BaseBoImpl implements Serializable, BaseBo {

	private String id;

	/**
	 * 金額
	 */
	private BigDecimal amt = BigDecimal.ZERO;

	/**
	 * 檢核訊息
	 * <p>
	 * 轉入醫檢費申請資料時，由費用系統依檢核條件檢核後產生檢核訊息儲存於此欄位
	 */
	private String checkMessage;

	/**
	 * 營利事業統編
	 */
	private String compId;

	/**
	 * 醫院代號
	 */
	private String hospitalId;

	/**
	 * 醫院中文
	 */
	private String hospitalName;

	/**
	 * 請款年月
	 */
	private String invitesFundsYears;

	/**
	 * 醫檢年月
	 */
	private String medicalYears;

	/**
	 * 印花總繳 選項有 Y：印花總繳 N："非"印花總繳
	 */
	private String stampTotalPay;

	/**
	 * 是否已轉入申請單
	 */
	private boolean appliedFormFlag;

	/**
	 * 扣繳業別
	 * 
	 * <pre>
	 * 1.財團法人預扣 2財團法人不預扣 3.非財團法人預扣 4.非財團法人不預扣  
	 * 系統需將選項值1&tilde;4轉換為”業別代號”及”是否代扣”兩個欄位
	 * 扣繳業別為1、3者，實付金額=體檢費用－（體檢費用*10%），業務報酬=費用合計*10%）
	 */
	private String withholdIndustry;

	/**
	 * 備註
	 */
	private String notes;

	/**
	 * 建檔日期
	 */
	private Calendar createDate;

	/**
	 * 更新日期
	 */
	private Calendar updateDate;

	/**
	 * 建檔人員。
	 */
	private User createUser;

	/**
	 * 更新人員。
	 */
	private User updateUser;

	/**
	 * 版本
	 */
	private Integer versionNo;

	// RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 start
	/**
	 * 印花稅代扣金額
	 */
	private BigDecimal stampDutyAmt = BigDecimal.ZERO;
	// RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 end

	/**
     * 
     */
	private List<MedicalExp> medicalExps;

	public MedicalExpApplDetail() {
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "uuid-hex")
	@Column(name = "ID", length = 72)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Basic()
	@Column(name = "AMT", nullable = false, precision = 16, scale = 4)
	public BigDecimal getAmt() {
		return this.amt;
	}

	public void setAmt(BigDecimal amt) {
		this.amt = amt;
	}

	@Basic()
	@Column(name = "CHECK_MESSAGE", length = 100)
	public String getCheckMessage() {
		return this.checkMessage;
	}

	public void setCheckMessage(String checkMessage) {
		this.checkMessage = checkMessage;
	}

	@Basic()
	@Column(name = "COMP_ID", nullable = false, length = 20)
	public String getCompId() {
		return this.compId;
	}

	public void setCompId(String compId) {
		this.compId = compId;
	}

	@Basic()
	@Column(name = "HOSPITAL_ID", nullable = false, length = 8)
	public String getHospitalId() {
		return this.hospitalId;
	}

	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}

	@Basic()
	@Column(name = "HOSPITAL_NAME", nullable = false, length = 100)
	public String getHospitalName() {
		return this.hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	@Basic()
	@Column(name = "INVITES_FUNDS_YEARS", nullable = false, length = 12)
	public String getInvitesFundsYears() {
		return this.invitesFundsYears;
	}

	public void setInvitesFundsYears(String invitesFundsYears) {
		this.invitesFundsYears = invitesFundsYears;
	}

	@Basic()
	@Column(name = "MEDICAL_YEARS", nullable = false, length = 12)
	public String getMedicalYears() {
		return this.medicalYears;
	}

	public void setMedicalYears(String medicalYears) {
		this.medicalYears = medicalYears;
	}

	@Basic()
	@Column(name = "STAMP_TOTAL_PAY", nullable = false, length = 2)
	public String getStampTotalPay() {
		return this.stampTotalPay;
	}

	public void setStampTotalPay(String stampTotalPay) {
		this.stampTotalPay = stampTotalPay;
	}

	@Basic()
	@Column(name = "APPLIED_FORM_FLAG", nullable = false, precision = 1)
	public boolean isAppliedFormFlag() {
		return this.appliedFormFlag;
	}

	public void setAppliedFormFlag(boolean appliedFormFlag) {
		this.appliedFormFlag = appliedFormFlag;
	}

	@Basic()
	@Column(name = "NOTES", nullable = true, length = 512)
	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	@Basic()
	@Column(name = "WITHHOLD_INDUSTRY", nullable = false, length = 4)
	public String getWithholdIndustry() {
		return this.withholdIndustry;
	}

	public void setWithholdIndustry(String withholdIndustry) {
		this.withholdIndustry = withholdIndustry;
	}

	// bi-directional many-to-one association to MedicalExp
	@OneToMany(mappedBy = "medicalExpApplDetail", fetch = FetchType.LAZY)
	public List<MedicalExp> getMedicalExps() {
		return this.medicalExps;
	}

	public void setMedicalExps(List<MedicalExp> medicalExps) {
		this.medicalExps = medicalExps;
	}

	/**
	 * @return 建檔人員
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TBEXP_CREATE_USER_ID", referencedColumnName = "ID")
	public User getCreateUser() {
		return createUser;
	}

	public void setCreateUser(User createUser) {
		this.createUser = createUser;
	}

	/**
	 * @return 更新人員
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TBEXP_UPDATE_USER_ID", referencedColumnName = "ID")
	public User getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(User updateUser) {
		this.updateUser = updateUser;
	}

	/**
	 * @return 建檔日期
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	public Calendar getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Calendar createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return 更新日期
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_DATE")
	public Calendar getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Calendar updateDate) {
		this.updateDate = updateDate;
	}

	@Version
	@Column(name = "VERSION_NO", nullable = false, precision = 20)
	public Integer getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(Integer versionNo) {
		this.versionNo = versionNo;
	}

	// RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 start
	@Basic()
	@Column(name = "STAMP_DUTY_AMT", precision = 16, scale = 4)
	public BigDecimal getStampDutyAmt() {
		return stampDutyAmt;
	}

	public void setStampDutyAmt(BigDecimal stampDutyAmt) {
		this.stampDutyAmt = stampDutyAmt;
	}
	// RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 end

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof MedicalExpApplDetail)) {
			return false;
		}
		MedicalExpApplDetail castOther = (MedicalExpApplDetail) other;
		return new EqualsBuilder().append(this.getId(), castOther.getId()).isEquals();
	}

	public int hashCode() {
		return new HashCodeBuilder().append(getId()).toHashCode();
	}

	public String toString() {
		return new ToStringBuilder(this).append("id", getId()).toString();
	}

}