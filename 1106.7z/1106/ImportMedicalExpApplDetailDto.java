package tw.com.skl.exp.kernel.model6.fileio.logic.dto;

import java.math.BigDecimal;

/**
 * 醫檢院匯入檔DTO。
 * 
 * 由核心轉入費用系統。
 * 
 * @author jackson
 * 
 */
public class ImportMedicalExpApplDetailDto extends AbstractDto {

	private static final long serialVersionUID = 7534507091640984383L;

	/** 醫院代號 */
	private String hospitalId;

	/** 醫院中文 */
	private String hospitalName;

	/** 印花稅總繳 */
	private String stampPay;

	/** 醫檢年月 */
	private String medicalYears;

	/** 醫檢費用 */
	private BigDecimal amt;

	/** 營利事業統編 */
	private String compId;

	/** 扣繳業別 */
	private String withholdIndustry;

	// RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 start
	/** 印花稅代扣金額 */
	private BigDecimal stampDutyAmt;

	// RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 end

	/**
	 * @return the hospitalId
	 */
	public String getHospitalId() {
		return hospitalId;
	}

	/**
	 * @param hospitalId
	 *            the hospitalId to set
	 */
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}

	/**
	 * @return the hospitalName
	 */
	public String getHospitalName() {
		return hospitalName;
	}

	/**
	 * @param hospitalName
	 *            the hospitalName to set
	 */
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	/**
	 * @return the stampPay
	 */
	public String getStampPay() {
		return stampPay;
	}

	/**
	 * @param stampPay
	 *            the stampPay to set
	 */
	public void setStampPay(String stampPay) {
		this.stampPay = stampPay;
	}

	/**
	 * @return the medicalYears
	 */
	public String getMedicalYears() {
		return medicalYears;
	}

	/**
	 * @param medicalYears
	 *            the medicalYears to set
	 */
	public void setMedicalYears(String medicalYears) {
		this.medicalYears = medicalYears;
	}

	/**
	 * @return the amt
	 */
	public BigDecimal getAmt() {
		return amt;
	}

	/**
	 * @param amt
	 *            the amt to set
	 */
	public void setAmt(BigDecimal amt) {
		this.amt = amt;
	}

	/**
	 * @return the compId
	 */
	public String getCompId() {
		return compId;
	}

	/**
	 * @param compId
	 *            the compId to set
	 */
	public void setCompId(String compId) {
		this.compId = compId;
	}

	public String getWithholdIndustry() {
		return withholdIndustry;
	}

	public void setWithholdIndustry(String withholdIndustry) {
		this.withholdIndustry = withholdIndustry;
	}

	// RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 start
	/**
	 * @return the stampDutyAmt
	 */
	public BigDecimal getStampDutyAmt() {
		return stampDutyAmt;
	}
	/**
	 * @param stampDutyAmt
	 *            the stampDutyAmt to set
	 */
	public void setStampDutyAmt(BigDecimal stampDutyAmt) {
		this.stampDutyAmt = stampDutyAmt;
	}
	// RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 end
	
}
