package tw.com.skl.exp.kernel.model6.logic.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import tw.com.skl.common.model6.logic.impl.BaseServiceImpl;
import tw.com.skl.common.model6.web.jsf.utils.Messages;
import tw.com.skl.exp.kernel.model6.bo.AccTitle;
import tw.com.skl.exp.kernel.model6.bo.ApplInfo;
import tw.com.skl.exp.kernel.model6.bo.ApplState;
import tw.com.skl.exp.kernel.model6.bo.Department;
import tw.com.skl.exp.kernel.model6.bo.Entry;
import tw.com.skl.exp.kernel.model6.bo.EntryGroup;
import tw.com.skl.exp.kernel.model6.bo.ExpType;
import tw.com.skl.exp.kernel.model6.bo.ExpapplC;
import tw.com.skl.exp.kernel.model6.bo.FlowCheckstatus;
import tw.com.skl.exp.kernel.model6.bo.Hospital;
import tw.com.skl.exp.kernel.model6.bo.MedicalExp;
import tw.com.skl.exp.kernel.model6.bo.MedicalExpApplDetail;
import tw.com.skl.exp.kernel.model6.bo.MedicalExpCostUnitMapping;
import tw.com.skl.exp.kernel.model6.bo.MiddleType;
import tw.com.skl.exp.kernel.model6.bo.PaymentTarget;
import tw.com.skl.exp.kernel.model6.bo.PaymentType;
import tw.com.skl.exp.kernel.model6.bo.ReturnStatement;
import tw.com.skl.exp.kernel.model6.bo.TransitPaymentDetail;
import tw.com.skl.exp.kernel.model6.bo.User;
import tw.com.skl.exp.kernel.model6.bo.AccTitle.AccTitleCode;
import tw.com.skl.exp.kernel.model6.bo.ApplState.ApplStateCode;
import tw.com.skl.exp.kernel.model6.bo.EntryType.EntryTypeCode;
import tw.com.skl.exp.kernel.model6.bo.EntryType.EntryTypeValueCode;
import tw.com.skl.exp.kernel.model6.bo.ExpType.ExpTypeCode;
import tw.com.skl.exp.kernel.model6.bo.Function.FunctionCode;
import tw.com.skl.exp.kernel.model6.bo.IncomeIdType.IncomeIdTypeCode;
import tw.com.skl.exp.kernel.model6.bo.MedicalWithholdFmt.MedicalWithholdFmtCode;
import tw.com.skl.exp.kernel.model6.bo.MiddleType.MiddleTypeCode;
import tw.com.skl.exp.kernel.model6.bo.PaymentTarget.PaymentTargetCode;
import tw.com.skl.exp.kernel.model6.bo.PaymentType.PaymentTypeCode;
import tw.com.skl.exp.kernel.model6.bo.SysType.SysTypeCode;
import tw.com.skl.exp.kernel.model6.common.ErrorCode;
import tw.com.skl.exp.kernel.model6.common.exception.ExpException;
import tw.com.skl.exp.kernel.model6.common.exception.ExpRuntimeException;
import tw.com.skl.exp.kernel.model6.common.util.AAUtils;
import tw.com.skl.exp.kernel.model6.common.util.MessageUtils;
import tw.com.skl.exp.kernel.model6.common.util.StringUtils;
import tw.com.skl.exp.kernel.model6.common.util.time.DateUtils;
import tw.com.skl.exp.kernel.model6.dao.MedicalExpDao;
import tw.com.skl.exp.kernel.model6.facade.MedicalExpFacade;
import tw.com.skl.exp.kernel.model6.logic.MedicalExpService;
import tw.com.skl.exp.kernel.model6.sn.AbstractSNGenerator;
import tw.com.skl.exp.kernel.model6.sn.ExpApplNoGenerator;
import tw.com.skl.exp.kernel.model6.sn.SNGenerator;

/**
 * 醫檢費用 Service 介面
 * 
 * @author Eustace
 * @version 1.0 2009/4/24
 */
/**
 * @author jackson
 * 
 */
public class MedicalExpServiceImpl extends BaseServiceImpl<MedicalExp, String, MedicalExpDao> implements
MedicalExpService {
    protected Log logger = LogFactory.getLog(this.getClass());
    private MedicalExpFacade facade;

    public MedicalExpFacade getFacade() {
        return facade;
    }

    public void setFacade(MedicalExpFacade facade) {
        this.facade = facade;
    }

    public void doGenerateExp(FunctionCode functionCode, String invitesFundsYears) throws ExpException {

        /* 檢核符合查詢條件該請款年月之醫檢費申請單是否為審核中，若是，不可重覆確認，畫面顯示訊息《醫檢資料核銷中，不可重覆確認》 */
        List<MedicalExpApplDetail> appliedMedExpApplList = getFacade().getMedicalExpApplDetailService()
        .findByInvitesFundsYears(invitesFundsYears, true);
        if (!CollectionUtils.isEmpty(appliedMedExpApplList)) {
            throw new ExpRuntimeException(ErrorCode.C10050);
        }

        // 依輸入的”請款年月”查出所有未轉入的醫檢費申請明細
        List<MedicalExpApplDetail> medExpApplList = getFacade().getMedicalExpApplDetailService()
        .findByInvitesFundsYears(invitesFundsYears, false);
        if (CollectionUtils.isEmpty(medExpApplList)) {
            throw new ExpRuntimeException(ErrorCode.C10028);
        }

        /*
         * 檢核6個服務中心是否於『轄屬設定』皆有設定初審經辦，若否，則不可進行資料確認動作(不可部份做資料確認)，系統須顯示《部份服務中心無初審經辦，
         * 請確認後再執行資料確認!》訊息
         */
        getFacade().getMedicalExpCostUnitMappingService().checkAllMedicalCostUnitCKindType();

        // 查出醫檢費的費用中分類預設為"B00 醫檢費"
        MiddleType middleType = getFacade().getMiddleTypeService().findByCode(MiddleTypeCode.CODE_B00.getCode());

        // 取得登入的使用者
        User user = this.facade.getUserService().findByPK(((User) AAUtils.getLoggedInUser()).getId());

        Calendar now = Calendar.getInstance();

        // 取得62080603維持費用-勞務費-其他勞務費
        AccTitle expAccTitle = getFacade().getAccTitleService().getAccTitleByParam("62080603");
        if (null == expAccTitle) {
            throw new ExpRuntimeException(ErrorCode.A10026, new String[] { "62080603" });
        }

        // 審核中狀態
        ApplState applStateFirstVerification = this.facade.getApplStateService().findByCodeFetchSysType(
                ApplStateCode.FIRST_VERIFICATION, SysTypeCode.C);

        // 退件狀態
        ApplState applStateReturnAppl = this.facade.getApplStateService().findByCodeFetchSysType(
                ApplStateCode.APPLICATION_REJECTED, SysTypeCode.C);

        //取得序號產生器
        SNGenerator gen = AbstractSNGenerator.getInstance(ExpApplNoGenerator.class.getName(), facade
                .getSequenceService());

        // 以相同「醫檢費用.請款年月」、「醫檢費用.服務中心」為產生送件單號的條件 2009/12/2
        Map<String, List<String>> toGenDeliverDaylistMap = new HashMap<String, List<String>>();// Key值為"請款年月(六碼)"+"服務中心代號(六碼)"，Value值為送件單號List

        for (MedicalExpApplDetail medExpApplDetail : medExpApplList) {

            MedicalExp exp = generateDefaultMedicalExp(medExpApplDetail, expAccTitle, user);

            // 取得序號產生器
            Map<String, String> params = new HashMap<String, String>();
            params.put("param1", middleType.getCode());
            
            String sn = gen.getSerialNumber(params);

            /*
             * 若有錯誤之檢核訊息(UC1.1.1轉入醫檢費用核銷申請資料之【檢核條件】2e~2h)，該件於按[資料確認]按鈕時，
             * 將該醫檢院申請件狀態為退件 ; 若該醫檢件有錯誤訊息，原因為"無統一編號"，於產生費用申請單時，將"退件碼"欄位修改為"N"，
             * 其他錯誤原因，於"退件碼"一律修改為"R"
             */
            String returnCode = getReturnCode(medExpApplDetail.getCheckMessage());
            if (StringUtils.isBlank(returnCode)) {
                exp.setReturnCode("");
                exp.getExpapplC().setApplState(applStateFirstVerification); // 審核中
            } else {
                exp.setReturnCode(returnCode);
                exp.getExpapplC().setApplState(applStateReturnAppl); // 退件
            }

            /*
             * 於「醫檢費申請明細」中，若「請款年月」欄位值之月份為「1月」時，於費用申請單之成本別需自動上W(為W件) (2009/12/8)             * 
             */
            if ("01".equals(StringUtils.substring(medExpApplDetail.getInvitesFundsYears(), 4, 6))){
                exp.getExpapplC().setCostTypeCode("W");
            }

            exp.getExpapplC().setWorkDate(now);
            exp.getExpapplC().setMiddleType(middleType);
            exp.getExpapplC().setExpApplNo(sn);
            exp.getExpapplC().setCreateDate(now);
            exp.getExpapplC().setCreateUser(user);

            /*
             * 依『有核定表UC7.5在職資料維護』分派申請單初審經辦:
             * 以新增的「費用申請單.申請人資訊.部門單位代號」查出、費用中分類代號”B00” 查詢費用項目轄屬(核銷)經辦。 參考SDD總綱的”
             * 以費用中分類代號、組織單位代號查詢費用項目轄屬(核銷)經辦”功能。 將查出的「使用者. 員工代號」設定至新增的「費用申請單.
             * 初審經辦」欄位
             */
            List<User> verifyUsers = facade.getCKindTypeService().findByMiddleTypeCode(
                    MiddleTypeCode.CODE_B00.getCode(), exp.getExpapplC().getApplyUserInfo().getDepUnitCode3());
            if (CollectionUtils.isEmpty(verifyUsers)) {
                throw new ExpRuntimeException(ErrorCode.C10068, new String[] { MiddleTypeCode.CODE_B00.getCode(),
                        exp.getExpapplC().getApplyUserInfo().getDepUnitCode3() });
            }
            exp.getExpapplC().setVerifyUser(verifyUsers.get(0));

            /* 產生應付費用科目帳務資料(分錄) */
            facade.getExpapplCService().generatePayableExpenseEntry(exp.getExpapplC(), null);

            /* 檢核費用申請單中，借貸是否平衡 */
            getFacade().getEntryGroupService().calcBalance(exp.getExpapplC().getEntryGroup());

            //成本別為W，執行W件控管..2010/1/14 for Defect#1832
            getFacade().getExpapplCService().handleCaseW(exp.getExpapplC());

            /*
             * 借方科目的摘要放「醫檢院名稱」
             * 貸方科目的摘要放「醫檢院名稱+統編」(#211) 
             */
            String hospitalName = StringUtils.trimToEmpty(exp.getHospital().getChinesesName());
            String compId = StringUtils.trimToEmpty(exp.getHospital().getCompId());
            for (Entry entry : exp.getExpapplC().getEntryGroup().getEntries()) {
                if (entry.getEntryType().getValue().equals(EntryTypeValueCode.D.getValue())){
                    entry.setSummary(hospitalName);
                }else{
                    entry.setSummary(hospitalName+compId);
                }
                entry.setEntryGroup(exp.getExpapplC().getEntryGroup());
            }
            
            //依成本單位代號設定(部門單位,區部單位)
            facade.getEntryService().generateUnitDepInfo(exp.getExpapplC().getEntryGroup().getEntries());

            /* 儲存費用申請單，並記錄流程簽核歷程 */
            getDao().create(exp);

            addTotoGenDeliverDaylistMap(toGenDeliverDaylistMap, exp);  

            /* 更新醫檢費申請明細的資料 */
            medExpApplDetail.setAppliedFormFlag(true);
            medExpApplDetail.setUpdateDate(now);
            medExpApplDetail.setUpdateUser(user);
            facade.getMedicalExpApplDetailService().update(medExpApplDetail);
            
            if (exp.getExpapplC().getApplState().getCode().equals(applStateReturnAppl.getCode())){ // 退件
                ReturnStatement statement = this.facade.getReturnStatementService()
                .getReturnStatement("00", medExpApplDetail.getCheckMessage());
                
                this.facade.getFlowCheckstatusService().createByExpApplC(functionCode, exp.getExpapplC(),
                        statement, now);
            }else{
                this.facade.getFlowCheckstatusService().createByExpApplC(exp.getExpapplC(),
                        functionCode, now);
            }
    
        }

        /*
         * 產生送件日計表 1. 以相同「醫檢費用.請款年月」、「醫檢費用.服務中心」為產生送件單號的條件 2. 送件經辦:
         * 以「使用者」關聯「行政轄屬單位」做為送件經辦
         */
        for (String keyStr: toGenDeliverDaylistMap.keySet()){
            List<String> applNoList = toGenDeliverDaylistMap.get(keyStr);
            facade.getDeliverDaylistService().doGenerateDeliverDayList(applNoList, functionCode,
                    ApplStateCode.FIRST_VERIFICATION);// 審核中
        }

    }

    /**
     * 將申請單號，加到相同的「醫檢費用.請款年月」、「醫檢費用.服務中心」List中
     * @param genMap
     * @param exp
     */
    private void addTotoGenDeliverDaylistMap(Map<String, List<String>> genMap, MedicalExp exp) {

        String keyStr = StringUtils.trim(exp.getInvitesFundsYears())
        + StringUtils.trim(exp.getMedicalExpCostUnit().getDepartment().getCode());
        if (null == genMap) {
            genMap = new HashMap<String, List<String>>();
            List<String> applNoList = new ArrayList<String>();
            applNoList.add(exp.getExpapplC().getExpApplNo());
            genMap.put(keyStr, applNoList);
        } else if (null == genMap.get(keyStr)) {
            List<String> applNoList = new ArrayList<String>();
            applNoList.add(exp.getExpapplC().getExpApplNo());
            genMap.put(keyStr, applNoList);
        } else {
            List<String> valueList = genMap.get(keyStr);
            valueList.add(exp.getExpapplC().getExpApplNo());
            genMap.put(keyStr, valueList);
        }
    }

    /**
     * 依醫檢費申請明細產生醫檢費用資料
     * 
     * @param medExpApplDetail
     * @param expAccTitle
     *            費用會計科目
     * @param loginUser
     *            登入的使用者
     * @return 醫檢費用資料
     */
    private MedicalExp generateDefaultMedicalExp(MedicalExpApplDetail medExpApplDetail, AccTitle expAccTitle,
            User loginUser) {

        Map<String, Object> criteriaMap;

        MedicalExp medicalExp = new MedicalExp();

        medicalExp.setMedicalExpApplDetail(medExpApplDetail);
        medicalExp.setInvitesFundsYears(medExpApplDetail.getInvitesFundsYears());

        // 查出醫檢院
        criteriaMap = new HashMap<String, Object>();
        criteriaMap.put("code", medExpApplDetail.getHospitalId());
        Hospital hospital = getFacade().getHospitalService().findByCriteriaMapReturnUnique(criteriaMap);
        if (null == hospital) {
            // 查無醫檢院資料，代號{0}
            throw new ExpRuntimeException(ErrorCode.C10051, new String[] { medExpApplDetail.getHospitalId() });
        }
        // "醫檢院代號"預設為轉入資料之"醫院代號"
        medicalExp.setHospital(hospital);

        // 依醫檢院代號第一碼取得「 醫檢費成本單位對照表(服務中心)」
        criteriaMap = new HashMap<String, Object>();
        criteriaMap.put("medicalFirstCode", StringUtils.substring(medExpApplDetail.getHospitalId(), 0, 1));
        MedicalExpCostUnitMapping medicalExpCostUnit = getFacade().getMedicalExpCostUnitMappingService()
        .findByCriteriaMapReturnUnique(criteriaMap);
        if (null == medicalExpCostUnit) {
            // 查無服務中心，醫檢院代號第一碼'{0}'
            throw new ExpRuntimeException(ErrorCode.C10052, new String[] { StringUtils.substring(medExpApplDetail
                    .getHospitalId(), 0, 1) });
        }
        medicalExp.setMedicalExpCostUnit(medicalExpCostUnit);

        // 建立費用申請單
        ExpapplC expapplC = new ExpapplC();

        expapplC.setExpYears(medExpApplDetail.getInvitesFundsYears());

        String userCode = null;
        String departmentCode = null;
        if (null != loginUser) {
            userCode = loginUser.getCode();
        }

        if (null != medicalExpCostUnit && null != medicalExpCostUnit.getDepartment()) {
            departmentCode = medicalExpCostUnit.getDepartment().getCode();
        }
        // 取得申請人資訊..建檔人 (申請單位代號、建檔單位代號"預設為"成本單位"(各服務中心)...TODO)
        ApplInfo applInfo = getFacade().getApplInfoService().generateApplyUserInfo(userCode, departmentCode);
        expapplC.setApplyUserInfo(applInfo);

        // "付款方式"為"1 匯款"
        PaymentType paymentType = getFacade().getPaymentTypeService().findByCodeFetchSysType(SysTypeCode.C,
                PaymentTypeCode.C_REMIT);
        expapplC.setPaymentType(paymentType);
        // "付款對象"為"3 廠商"
        PaymentTarget paymentTarget = getFacade().getPaymentTargetService().findByCodeFetchSysType(SysTypeCode.C,
                PaymentTargetCode.VENDOR);
        expapplC.setPaymentTarget(paymentTarget);
        // "費用性質"預設為"3 一般"
        ExpType expType = getFacade().getExpTypeService().findExpTypeByExpTypeCode(ExpTypeCode.GENERAL);
        expapplC.setExpType(expType);
        // 憑證類別設為NULL
        expapplC.setProofType(null);
        // 成本別
        expapplC.setCostTypeCode(" ");
        expapplC.setInvoiceAmt(medExpApplDetail.getAmt());

        /*
         * 印花稅總繳= N時 <ul> <li>代扣20210217應付代收款-體檢費印花稅</li> </ul>
         */

        boolean isGenerateStampTax = false;// 是否產生印花稅

        if ("N".equalsIgnoreCase(StringUtils.trim(medExpApplDetail.getStampTotalPay()))) {
            isGenerateStampTax = true;
        }

        // 取得成本單位
        Department costDep = facade.getDepartmentService().getCostUnit(medicalExpCostUnit.getDepartment().getCode());

        // 產生分錄
        List<Entry> entries = generateMedicalExpEntries(expapplC, medExpApplDetail.getAmt(), expAccTitle, hospital,
                costDep, isGenerateStampTax, "", medExpApplDetail);

        // 分錄群組
        EntryGroup entryGroup = new EntryGroup();
        entryGroup.setEntries(entries);
        expapplC.setEntryGroup(entryGroup);

        medicalExp.setExpapplC(expapplC);

        return medicalExp;
    }

    /**
     * 產生醫檢費用分錄資料
     * 
     * @param expapplC
     *            費用申請單(要填入"所得稅"、"印花稅"、"實付金額"等欄位)
     * @param amt
     *            明細金額
     * @param expAccTitle
     *            費用會計科目
     * @param hospital
     *            醫檢院
     * @param costDep
     *            成本單位
     * @param isGenerateStampTax
     *            是否產生印花稅
     * @return 分錄List
     */
    public List<Entry> generateMedicalExpEntries(ExpapplC expapplC, BigDecimal amt, AccTitle expAccTitle,
            Hospital hospital, Department costDep, boolean isGenerateStampTax, String summary, MedicalExpApplDetail medExpApplDetail) {
        /** 產生分錄 */
        List<Entry> entries = new ArrayList<Entry>();

        /* 產生借方費用科目，"費用金額"預設為轉入資料之"醫檢費用" */
        Entry expEntry = new Entry();
        expEntry.setAccTitle(expAccTitle);
        // 借方
        expEntry.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_1_D));

        expEntry.setAmt(amt);
        expEntry.setCostUnitCode(costDep.getCode());
        expEntry.setCostUnitName(costDep.getName());// modified by
        // JacksonLee..2009/10/1
        // 業別代號
        expEntry.setIndustryCode(hospital.getIndustryCode());
        //2010/1/27,費用科目分錄需填上摘要,defect 1964
        if(StringUtils.isNotBlank(summary)){
            expEntry.setSummary(summary);
        }
        entries.add(expEntry);

        // 產生印花稅
        if (isGenerateStampTax) {
            Entry stampTaxEntry = new Entry(); // 印花稅
            // 貸方
            stampTaxEntry.setEntryType(facade.getEntryTypeService()
                    .findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_1_C));
            stampTaxEntry.setAccTitle(expAccTitle.getStampTax());

            //RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 start
            //BigDecimal stampAmt = getFacade().getAccTitleService().calculateStampAmt(expAccTitle.getCode(), amt);
            BigDecimal stampAmt = medExpApplDetail.getStampDutyAmt();
            //  RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 end
            
            stampTaxEntry.setAmt(stampAmt);
            if (stampAmt.compareTo(BigDecimal.ZERO) > 0) {

                entries.add(stampTaxEntry);

                // 印花稅
                expapplC.setWithholdStamp(true);
            }
            expapplC.setStampAmt(stampAmt);
        }

        /*
         * 印花稅總繳= N時 <ul> <li>代扣20210217應付代收款-體檢費印花稅</li> <li>印花稅總繳= N時，實付金額
         * =體檢費用－（體檢費用*10%）- (醫檢費用 *印花稅率)</li> </ul> 印花稅總繳= Y時 <ul>
         * <li>扣繳業別為1、3者，實付金額=體檢費用－（體檢費用*10%），業務報酬=費用合計*10%</li>
         * <li>扣繳業別為2、4者，實付金額=體檢費用</li> </ul>
         */
        boolean isGenerateTax = false;// 是否產生代扣科目

        if (medExpApplDetail != null)
        {
            /*  IF (印花稅總繳= N)  AND  (扣繳業別為1、3) --代扣
             *    實付金額 =體檢費用－（體檢費用*10%）- (醫檢費用 *印花稅率)
             *  IF (印花稅總繳= N) AND  (扣繳業別為2、4)  --不代扣
             *    實付金額=體檢費用 - (醫檢費用 *印花稅率)
             *  IF (印花稅總繳= Y) AND  (扣繳業別為1、3)  --代扣
             *    實付金額 =體檢費用－（體檢費用*10%）    
             *  IF (印花稅總繳= Y) AND  (扣繳業別為2、4)  --不代扣
             *   實付金額 =體檢費用
             *  20101014 陳彥文 RE201002277
             */
             if (isGenerateStampTax)  //要產生印花稅, 印花稅總繳= N
             {
                if ("1".equals(StringUtils.trim(medExpApplDetail.getWithholdIndustry())) || "3".equals(StringUtils.trim(medExpApplDetail.getWithholdIndustry()))) //扣繳業別為1,或3
                {
                    isGenerateTax = true;
                }
                
                if ("2".equals(StringUtils.trim(medExpApplDetail.getWithholdIndustry())) || "4".equals(StringUtils.trim(medExpApplDetail.getWithholdIndustry()))) //扣繳業別為2,或4
                {
                    isGenerateTax = false;
                }
             }
             else
             {
                if ("1".equals(StringUtils.trim(medExpApplDetail.getWithholdIndustry())) || "3".equals(StringUtils.trim(medExpApplDetail.getWithholdIndustry()))) //扣繳業別為1,或3
                {
                    isGenerateTax = true;
                }
                
                if ("2".equals(StringUtils.trim(medExpApplDetail.getWithholdIndustry())) || "4".equals(StringUtils.trim(medExpApplDetail.getWithholdIndustry()))) //扣繳業別為2,或4
                {
                    isGenerateTax = false;
                }
             }
        }
        else //舊的程式碼放在下面
        {
	        /*
	         * 依「醫檢院.業別代號」，決定是否代扣20210229應付代收款-執行業務報酬(其他) 52: 一定產生 8Z:
	         * 「醫檢院.是否代扣財團法人所得」=true，要產生
	         */
	        if (isGenerateStampTax) {
	            isGenerateTax = true;
	        } else {
	            if (StringUtils.equalsIgnoreCase(Hospital.INDUSTRY_CODE_INSURE, hospital.getIndustryCode())) {
	                isGenerateTax = true;
	            } else {
	                if (hospital.isWithheldLegalPersonIncome()) {
	                    isGenerateTax = true;
	                }
	            }
	        }
        }
        // 產生代扣科目
        if (isGenerateTax) {
            Entry taxEntry = new Entry();
            taxEntry.setAccTitle(expAccTitle.getWithhold());
            // 貸方
            taxEntry.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_1_C));

            // 計算業務報酬(所得稅)
            BigDecimal taxAmt = getFacade().getAccTitleService().calculateTaxAmt(expAccTitle, amt, false);

            if (taxAmt.compareTo(BigDecimal.ZERO) > 0) {
                taxEntry.setAmt(taxAmt);
                // 依扣繳格式決定 以"統一編號"做為扣繳對象 或 該醫檢院"負責人身份證字號 "做為扣繳對象
                if (hospital.getMedicalWithholdFmt().getCode().equals(MedicalWithholdFmtCode.HOSPITAL)) {
                    taxEntry.setIncomeIdType(IncomeIdTypeCode.COMP_ID.getCode());
                    taxEntry.setIncomeId(hospital.getCompId());
                } else {// 以負責人身份證字號
                    taxEntry.setIncomeIdType(IncomeIdTypeCode.IDENTITY_ID.getCode());
                    taxEntry.setIncomeId(hospital.getPersonIdentityId());
                }

                entries.add(taxEntry);
            }
            // 所得稅
            expapplC.setTaxAmt(taxAmt);
        }

        // 計算實付金額: 實付金額 =體檢費用－代扣金額－印花稅額
        BigDecimal realityAmt = expEntry.getAmt().subtract(expapplC.getTaxAmt()).subtract(expapplC.getStampAmt());
        expapplC.setRealityAmt(realityAmt);

        return entries;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * tw.com.skl.exp.kernel.model6.logic.MedicalExpService#doReapplyApplyForm
     * (java.lang.String)
     */
    public MedicalExp doReapplyApplyForm(String expApplNo) throws ExpException {
        List<String> expApplNoList = new ArrayList<String>();
        expApplNoList.add(expApplNo);
        // 因為只有一組申請單號，所以只會查出一筆費用申請單
        ExpapplC eac = facade.getExpapplCService().findByApplNo(expApplNoList).get(0);
        if (!ObjectUtils.equals(ApplStateCode.APPLICATION_REJECTED.getCode(), eac.getApplState().getCode())) {
            throw new ExpRuntimeException(ErrorCode.C10020);
        }
        // 將「醫檢費用.費用申請單.申請單狀態」設為"審核中"，
        // 並更新「醫檢費用.費用申請單. 補辦完成日期」、「費用申請單.初審經辦」為登入的使用者
        Map<String, Object> criteriaMap = new HashMap<String, Object>();
        criteriaMap.put("expapplC", eac);
        MedicalExp mExp = getDao().findByCriteriaMap(criteriaMap).get(0);
        Calendar nowDate = Calendar.getInstance();
        mExp.getExpapplC().setApplState(
                facade.getApplStateService().findByCodeFetchSysType(ApplStateCode.FIRST_VERIFICATION, SysTypeCode.C));
        mExp.getExpapplC().setResendVerifyDate(nowDate);
        // 2009/09/09,Tim,修正補辦後，更新實際初審經辦
        mExp.getExpapplC().setActualVerifyUser(getLoginUser());
        // 設定「醫檢費用.退件碼」=空白
        mExp.setReturnCode("");

        // 更新費用申請單，記錄流程簽核歷程
        mExp = getDao().update(mExp);
        // facade.getExpapplCService().update(eac);
        facade.getFlowCheckstatusService().createByExpApplC(eac, FunctionCode.C_3_2_1, nowDate);
        logger.debug("MExpDoReapply**ExpApplNo::" + eac.getExpApplNo() + ":: ExpApplState=="
                + eac.getApplState().getName() + ":: VerifyUserIs :: " + eac.getVerifyUser());
        return mExp;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * tw.com.skl.exp.kernel.model6.logic.MedicalExpService#doReturnApplyForm
     * (java.lang.String)
     */
    public MedicalExp doReturnApplyForm(String expApplNo, ReturnStatement rs) throws ExpException {
        List<String> expApplNoList = new ArrayList<String>();
        expApplNoList.add(expApplNo);
        // 因為只有一組申請單號，所以只會查出一筆費用申請單
        ExpapplC eac = facade.getExpapplCService().findByApplNo(expApplNoList).get(0);
        // 查出醫檢費用資料
        Map<String, Object> criteriaMap = new HashMap<String, Object>();
        criteriaMap.put("expapplC", eac);
        MedicalExp mExp = getDao().findByCriteriaMap(criteriaMap).get(0);
        // 2009/11/04,TIM,user需求為"審核中"或是"退單審核"狀態，才可以退件。2009/11/27,CR#227加上"退回審核"
        // 申請狀態必須是"審核中"
        if (!(ApplStateCode.FIRST_VERIFICATION.getCode().equals(eac.getApplState().getCode())
                || ApplStateCode.RETURN_EXPAPPL_VERIFICATION.getCode().equals(eac.getApplState().getCode()) || ApplStateCode.FIRST_VERIFICATION_REJECTED
                .getCode().equals(eac.getApplState().getCode()))) {
            throw new ExpRuntimeException(ErrorCode.C10060);
        }
        // 找出退件原因
        if (ObjectUtils.equals("99", rs.getReturnCause().getRetCause())) {
            throw new ExpRuntimeException(ErrorCode.C10059);
        }
        User logonUser = (User) AAUtils.getLoggedInUser();
        logonUser = facade.getUserService().findByPK(logonUser.getId());
        // 設定「醫檢費用.費用申請單.實際初審經辦」為登入的使用者，並將「醫檢費用.費用申請單.申請單狀態」設為"退件"
        mExp.getExpapplC().setActualVerifyUser(logonUser);
        mExp.getExpapplC().setApplState(
                facade.getApplStateService().findByCodeFetchSysType(ApplStateCode.APPLICATION_REJECTED, SysTypeCode.C));
        mExp.setReturnCode("R");

        // 更新「費用申請單」＆ 儲存申請單資料，並記錄「流程簽核歷程」及「流程簽核歷程.退件原因說明」
        mExp = getDao().update(mExp);
        // eac = facade.getExpapplCService().update(eac);
        // mExp.setExpapplC(eac);
        facade.getFlowCheckstatusService().createByExpApplC(FunctionCode.C_3_2_1, eac, rs, Calendar.getInstance());
        return mExp;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * tw.com.skl.exp.kernel.model6.logic.MedicalExpService#findForApprove(java
     * .lang.String, java.lang.String, java.lang.String, java.lang.String,
     * tw.com.skl.exp.kernel.model6.bo.ApplState.ApplStateCode[])
     */
    public List<MedicalExp> findForApprove(String invitesFundsYears, String hospitalCode, String hospitalName,
            String userCode, ApplStateCode[] states) {
        StringBuffer querySql = new StringBuffer();
        querySql.append("select medicalExp from MedicalExp medicalExp" + " join medicalExp.expapplC eac"
                + " join medicalExp.hospital hospito");
        boolean truncated = false;
        Map<String, Object> params = new HashMap<String, Object>();
        // 初審經辦.員工代號
        if (!truncated) {
            querySql.append(" join eac.verifyUser vu where");
            truncated = true;
        }
        querySql.append(" eac.verifyUser.code=:userCode");
        querySql.append(" and");
        // 登入人員是否有傳入值
        if (StringUtils.isNotBlank(userCode)) {
            params.put("userCode", userCode);
        } else {
            // 使用預設：登入人員
            params.put("userCode", getLoginUser().getCode());
        }

        // 請款年月
        if (StringUtils.isNotBlank(invitesFundsYears)) {
            if (!truncated) {
                querySql.append(" where");
                truncated = true;
            }
            querySql.append(" medicalExp.invitesFundsYears=:invitesFundsYears");
            params.put("invitesFundsYears", invitesFundsYears);
            querySql.append(" and");
        }
        // 醫檢院代號
        if (StringUtils.isNotBlank(hospitalCode)) {
            if (!truncated) {
                querySql.append(" where");
                truncated = true;
            }
            querySql.append(" hospito.code=:hospitalCode");
            params.put("hospitalCode", hospitalCode);
            querySql.append(" and");
        }
        // 醫檢院中文名稱
        if (StringUtils.isNotBlank(hospitalName)) {
            if (!truncated) {
                querySql.append(" where");
                truncated = true;
            }
            querySql.append(" hospito.name=:hospitalName");
            params.put("hospitalName", hospitalName);
            querySql.append(" and");
        }
        // 申請單狀態
        boolean cutStringIsOR = false;
        if (states != null && states.length > 0) {
            int count = 0;
            if (!truncated) {
                querySql.append(" where (");
                truncated = true;
            } else {
                querySql.append(" (");
            }
            for (ApplStateCode state : states) {
                querySql.append(" eac.applState.code=:state" + count);
                params.put("state" + count, state.getCode());
                querySql.append(" or");
                count++;
            }
            cutStringIsOR = true;
        }
        // 如果申請單狀態有加入查詢的Sql中，那就要把or清掉，並且加上最後的)
        if (truncated && cutStringIsOR) {
            querySql.delete(querySql.lastIndexOf("or"), querySql.length());
            querySql.append(" )");
        } else if (truncated && !cutStringIsOR) {
            querySql.delete(querySql.lastIndexOf("and"), querySql.length());
        }
        querySql.append(" order by hospito.code, medicalExp.medicalExpApplDetail.invitesFundsYears");
        List<MedicalExp> list = null;
        list = getDao().findByNamedParams(querySql.toString(), params);
        return list;
    }

    /*
     * (non-Javadoc)
     * 
     * @seetw.com.skl.exp.kernel.model6.logic.MedicalExpService#
     * findMedicalExpApprovedResult(java.lang.String, java.lang.String,
     * java.lang.String)
     */
    public List<Map<String, Object>> findMedicalExpApprovedResult(String invitesFundsYears, String medicalFirstCode,
            String hospitalCode) {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * 取得醫檢費用退件碼
     * <ol>
     * <li>若原因為”無統一編號”，於產生費用申請單時，將「醫檢費用.退件碼」欄位修改為”N”</li>
     * <li>其他錯誤原因，於”退件碼”一律修改為”R”</li>
     * </ol>
     * 
     * @param checkMessage
     *            醫檢費申請明細的檢核訊息
     */
    private String getReturnCode(String checkMessage) {

        String noCompIdMsg = MessageUtils.getAccessor().getMessage("C10044");// 無統一編號
        if (StringUtils.isBlank(checkMessage)) {
            return "";
        } else if (StringUtils.indexOf(checkMessage, noCompIdMsg) != -1) {
            return "N";
        } else {
            return "R";
        }

    }

    /*
     * 1. 使用者勾選或全選申請單後，按下”核銷”按鈕，取得所有勾選的「醫檢費用」 2.
     * 若選擇核銷之「醫檢費用.費用申請單.申請單狀態」不為"審核中"時，顯示《狀態錯誤，尚未完成核銷》訊息，且須回復已更新狀態之資料列 3.
     * 設定所有「費用申請單.實際初審經辦」為登入的使用者，並將「費用申請單.申請單狀態」設為”已初審” 4. 儲存申請單資料，並記錄”流程簽核歷程”
     * 5. 計算核銷的筆數，並顯示《"件數(系統計算選擇核銷之筆數)"已核銷》訊息 6. 重新執行查詢
     */
    public Integer doApproveMedicalExp(List<MedicalExp> mExpList) throws ExpException {
        int count = 0;
        Calendar nowDate = Calendar.getInstance();
        for (MedicalExp mExp : mExpList) {
            if (mExp == null) {
                throw new ExpRuntimeException(ErrorCode.A10007, new String[] { MessageUtils.getAccessor().getMessage(
                "tw_com_skl_exp_kernel_model6_bo_MedicalExp") });
            }
            ExpapplC eac = mExp.getExpapplC();
            //2009/12/7,只有審核中、和退回審核可以作核銷
            if (!ApplStateCode.FIRST_VERIFICATION.getCode().equals(eac.getApplState().getCode())
                    && !ApplStateCode.FIRST_VERIFICATION_REJECTED.getCode().equals(eac.getApplState().getCode()) ) {
                throw new ExpRuntimeException(ErrorCode.C10019);
            }
            User logonUser = (User) AAUtils.getLoggedInUser();
            logonUser = facade.getUserService().findByPK(logonUser.getId());
            eac.setActualVerifyUser(logonUser);
            eac.setApplState(facade.getApplStateService().findByCodeFetchSysType(ApplStateCode.FIRST_VERIFIED,
                    SysTypeCode.C));

            // 只要更新「費用申請單」＆記錄「流程簽核歷程」
            facade.getExpapplCService().update(eac);
            facade.getFlowCheckstatusService().createByExpApplC(eac, FunctionCode.C_3_2_1, nowDate);
            count++;
        }
        return count;
    }

    public TransitPaymentDetail generateTransitPaymentDetail(ExpapplC expapplC) throws ExpException {
        /*
         * 由「費用申請單.分錄群組.分錄」List中，取得以下應付費用科目的分錄。 若沒有出現任何一筆或大於一筆，throw new
         * ExpRuntimeException， 顯示《分錄資料錯誤，只能存在唯一的應付費用會計科目》
         */
        if (expapplC == null) {
            String[] param = { Messages.getString("applicationResources",
                    "tw_com_skl_exp_kernel_model6_bo_ChangeAccruedExpDetail_expapplC", null) };
            throw new ExpRuntimeException(ErrorCode.A10007, param);
        }
        if (CollectionUtils.isEmpty(expapplC.getEntryGroup().getEntries())) {
            throw new ExpRuntimeException(ErrorCode.C10064);
        }
        //2009/12/25,新增內結時，醫檢費用，過渡付款明細處理檢核
        MedicalExp mexp = findByExpapplC(expapplC);
        Hospital hsp = mexp.getHospital()!=null ? mexp.getHospital() :null;
        if(hsp==null)throw new ExpRuntimeException(ErrorCode.A20008,
                new String[]{MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_Hospital")
                ,MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_Hospital_chinesesName")});
        if(StringUtils.isNotBlank(hsp.getOutwardBankCode()) && hsp.getOutwardBankCode().length()==7){
            if("700".equals(hsp.getOutwardBankCode().substring(0, 3)) && StringUtils.isBlank(hsp.getRemitAccid())){
                throw new ExpRuntimeException(ErrorCode.C10432,new String[]{expapplC.getExpApplNo(),hsp.getChinesesName()});
            }
        }
        String accruedExpCode = "";
        for (String code : AccTitle.EXP_PAYABLE_ACCOUNTS) {
            accruedExpCode = code + "&" + accruedExpCode;
        }
        Entry accruedExpEn = null;
        int count = 0;
        for (Entry en : expapplC.getEntryGroup().getEntries()) {
            // 查詢應付費用是否大於一筆
            if (accruedExpCode.indexOf(en.getAccTitle().getCode()) >= 0) {
                if (null == accruedExpEn) {
                    accruedExpEn = en;
                    count++;
                }
                if (count > 1)
                    // 顯示《分錄資料錯誤，只能存在唯一的應付費用會計科目》
                    throw new ExpRuntimeException(ErrorCode.A10033);
            }
        }
        // 沒有任何一筆
        if (accruedExpEn == null)
            throw new ExpRuntimeException(ErrorCode.A10033);
        // 系統時間
        Calendar nowDate = Calendar.getInstance();
        // new 一個「過渡付款明細」待回傳
        TransitPaymentDetail tPD = new TransitPaymentDetail();
        // 查出相關資料
        StringBuffer querySql = new StringBuffer();
        querySql.append("select medExp from MedicalExp medExp" + " join medExp.expapplC eac"
                + " join medExp.hospital htpl" + " where eac.expApplNo=:eaplno");
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("eaplno", expapplC.getExpApplNo());
        List<MedicalExp> medExps = getDao().findByNamedParams(querySql.toString(), params);
        MedicalExp medExp = medExps.get(0);
        /*
         * 付款方式 = 費用申請單.付款方式 票據抬頭/匯款戶名 = 醫檢院.戶名 受款總行 = 醫檢院.解款行代號前三碼 受款分行 =
         * 醫檢院.解款行代號後四碼 匯款帳號 = 醫檢院.帳號 金額 = 應付費用科目分錄.金額 廠商統編 = 醫檢院.醫檢院統編 受款人代號
         * =醫檢院.匯款開戶ID 單位代號 = 醫檢院.醫檢院代號 幣別 = 固定為”台幣” 分錄 = 應付費用科目分錄 付款來源 = ???
         * 付款摘要 = ??? 付款處理 = 依「費用申請單.付款方式」決定 A:開票、匯款 M:繳款件 申請單號 = 「費用申請單.申請單號」
         */
        // 修改付款方式的值
        if (PaymentTypeCode.C_REMIT.getCode().equals(expapplC.getPaymentType().getCode())) {
            tPD.setPaymentType("R");
        } else if (PaymentTypeCode.C_CHECK.getCode().equals(expapplC.getPaymentType().getCode())) {
            tPD.setPaymentType("C");
        }
        tPD.setAccountName(medExp.getHospital().getAccountName());
        tPD.setRemitBank(medExp.getHospital().getOutwardBankCode().substring(0, 3));
        tPD.setRemitSubbank(medExp.getHospital().getOutwardBankCode().substring(3, 7));
        tPD.setRemitAccount(medExp.getHospital().getAccountNo());
        BigDecimal tPDPaymentAmt = BigDecimal.ZERO; // 過渡付款明細.金額
        for (Entry en : expapplC.getEntryGroup().getEntries()) {
            // 應付費用科目20210391、20210392、20210393、20210360。而且只會有一筆資料
            if (accruedExpCode.indexOf(en.getAccTitle().getCode()) >= 0) {
                tPDPaymentAmt = en.getAmt();
                break;
            }
        }
        tPD.setPaymentAmt(tPDPaymentAmt);
        tPD.setCompId(medExp.getHospital().getCompId());
        tPD.setRemitAccId(medExp.getHospital().getCompId());
        tPD.setDepartmentId(medExp.getHospital().getCode());
        // 付款來源 = ???
        // tPD.setPaymentSource(paymentSource);
        // 付款摘要 = ???
        // tPD.setPaymentDesc(paymentDesc);
        // 付款處理
        String manualInd = "";
        if (PaymentTypeCode.C_CHECK.getCode().equals(expapplC.getPaymentType().getCode())
                || PaymentTypeCode.C_REMIT.getCode().equals(expapplC.getPaymentType().getCode())) {
            manualInd = "A";    //A:開票、匯款
        } else if (PaymentTypeCode.C_PAYMENT.getCode().equals(expapplC.getPaymentType().getCode())) {
            manualInd = "M";    //M:繳款件
        }
        tPD.setManualInd(manualInd);
        tPD.setExpApplNo(expapplC.getExpApplNo());
        // 更新人員
        tPD.setCreateUserId(getLoginUser().getCode());
        // 更新日期
        tPD.setCreateDate(nowDate);
        // 分錄資料
        tPD.setEntry(accruedExpEn);
        //2009/12/24,呼叫付款處理、付款來源的處理方法
        facade.getTransitPaymentDetailService().doProcessTransitPaymentDetail(expapplC, tPD);
        tPD = facade.getTransitPaymentDetailService().create(tPD);
        return tPD;
    }

    public List<String> findMedicalExpApproveResultExport(String invitesFundsYears) {
        if (StringUtils.isBlank(invitesFundsYears)) {
            throw new ExpRuntimeException(ErrorCode.C10054);
        }
        StringBuffer querySql = new StringBuffer();
        // 申請單狀態為"日結"or"退件"
        // 醫檢費用.請款年月 = 傳入的請款年月
        // 以申請單的申請單號排序
        querySql.append("select mexp from MedicalExp mexp" + " join mexp.expapplC eac"
                + " join eac.applState applState" + " where ( applState.code='" + ApplStateCode.DAILY_CLOSED.getCode()
                + "' or applState.code='" + ApplStateCode.APPLICATION_REJECTED.getCode()
                + "' ) and mexp.invitesFundsYears=:invitesFundsYears order by eac.expApplNo");
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("invitesFundsYears", invitesFundsYears);
        List<MedicalExp> mexpList = getDao().findByNamedParams(querySql.toString(), params);

        List<String> result = new ArrayList<String>();
        if (CollectionUtils.isEmpty(mexpList)) {
            throw new ExpRuntimeException(ErrorCode.A20002, new String[] { Messages.getString("applicationResources",
                    "tw_com_skl_exp_kernel_model6_bo_MedicalExpApplDetail_no_data_found", null) });
        }
        for (MedicalExp mexp : mexpList) {
            result.add(assembleMedicalExpApproveResult(mexp));
        }
        return result;
    }

    private String assembleMedicalExpApproveResult(MedicalExp mexp) {
        logger.debug("assembleMedicalDate");
        final String SYMBOL = ",";
        StringBuffer result = new StringBuffer();
        MedicalExpApplDetail mexpApplDetail = mexp.getMedicalExpApplDetail();
        // 醫院代號
        result.append(mexpApplDetail.getHospitalId());
        result.append(SYMBOL);
        // 醫檢年月
        result.append(mexpApplDetail.getMedicalYears());
        result.append(SYMBOL);
        // 費用合計
        result.append(mexpApplDetail.getAmt());
        result.append(SYMBOL);
        // 實匯金額
        BigDecimal remitAmt = mexpApplDetail.getAmt().subtract(mexp.getExpapplC().getStampAmt());
        for (Entry en : mexp.getExpapplC().getEntryGroup().getEntries()) {
            // 應付代收款--執行業務報酬
            if (AccTitleCode.BUSINESS_REWARDS.getCode().equals(en.getAccTitle().getCode())) {
                remitAmt = remitAmt.subtract(en.getAmt());
            }
        }
        result.append(remitAmt);
        result.append(SYMBOL);

        // 審核日期--最後一筆「流程簽核歷程.傳簽狀態代號」=”已內結”的資料
        FlowCheckstatus flowCheckstatus = facade.getFlowCheckstatusService().findFlowCheckStatusDateForInClose(
                mexp.getExpapplC().getExpApplNo());
        if (null != flowCheckstatus) {
            // 2009/12/8,日期不用加"-"
            result.append(DateUtils.getSimpleISODateStr(flowCheckstatus.getApproveDate().getTime()));
        }
        result.append(SYMBOL);

        // 退件碼
        result.append(mexp.getReturnCode() != null ? mexp.getReturnCode() : "");
        result.append(SYMBOL);
        // 請款年月
        result.append(mexp.getInvitesFundsYears() + " ");

        return result.toString();
    }

    public MedicalExp findByExpapplC(ExpapplC eac){
        return getDao().findByExpapplC(eac);
    }


    /**
     * <p>
     * 取得登入人員資料
     * </p>
     * 
     * @return User 使用者
     */
    private User getLoginUser() {
        User user = this.facade.getUserService().findByPK(((User) AAUtils.getLoggedInUser()).getId());
        return user;
    }
}