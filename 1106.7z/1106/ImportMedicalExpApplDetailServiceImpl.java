package tw.com.skl.exp.kernel.model6.fileio.logic.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import tw.com.skl.exp.kernel.model6.bo.Hospital;
import tw.com.skl.exp.kernel.model6.bo.MedicalExpApplDetail;
import tw.com.skl.exp.kernel.model6.bo.MedicalExpCostUnitMapping;
import tw.com.skl.exp.kernel.model6.bo.User;
import tw.com.skl.exp.kernel.model6.bo.MiddleType.MiddleTypeCode;
import tw.com.skl.exp.kernel.model6.common.ErrorCode;
import tw.com.skl.exp.kernel.model6.common.exception.ExpRuntimeException;
import tw.com.skl.exp.kernel.model6.common.util.AAUtils;
import tw.com.skl.exp.kernel.model6.common.util.MessageUtils;
import tw.com.skl.exp.kernel.model6.common.util.StringUtils;
import tw.com.skl.exp.kernel.model6.common.util.time.DateUtils;
import tw.com.skl.exp.kernel.model6.fileio.logic.AbstractFileImportService;
import tw.com.skl.exp.kernel.model6.fileio.logic.ImportMedicalExpApplDetailService;
import tw.com.skl.exp.kernel.model6.fileio.logic.dto.ImportMedicalExpApplDetailDto;
import tw.com.skl.exp.kernel.model6.fileio.reader.FileReader;
import tw.com.skl.exp.kernel.model6.fileio.strategy.ParseStrategy;
import tw.com.skl.exp.kernel.model6.logic.CKindTypeService;
import tw.com.skl.exp.kernel.model6.logic.HospitalService;
import tw.com.skl.exp.kernel.model6.logic.MedicalExpApplDetailService;
import tw.com.skl.exp.kernel.model6.logic.MedicalExpCostUnitMappingService;
import tw.com.skl.exp.kernel.model6.logic.UserService;

/**
 * 轉入醫檢費用核銷申請資料類別。
 * 
 * <ul><li>C 1.1.1 轉入醫檢費用核銷申請資料</li></ul>
 * 
 * @author jackson 
 */
public class ImportMedicalExpApplDetailServiceImpl extends AbstractFileImportService implements ImportMedicalExpApplDetailService {

    private MedicalExpApplDetailService medicalExpApplDetailService;

    private HospitalService hospitalService;

    private MedicalExpCostUnitMappingService medicalExpCostUnitMappingService;

    private CKindTypeService cKindTypeService;

    private UserService userService;



    /**
     * 回傳Map的Key/Value:
     * "TOTAL_AMT": 總金額(BigDecimal)
     * "TOTAL_COUNT": 總筆數(Integer)
     * @see tw.com.skl.exp.kernel.model6.fileio.logic.AbstractFileImportService#importData(tw.com.skl.exp.kernel.model6.fileio.reader.FileReader, java.util.Map)
     */
    @Override
    protected Map<String, Object> importData(FileReader reader, Map<String, Object> params) {

        // 檢核欲上傳之檔案名稱是否為「hoss10.csv」，若否，顯示《檔案錯誤，檔名需為hoss10.csv!!》
        if (!StringUtils.startsWithIgnoreCase(reader.getFileName(), this.getFileName())){
            throw new ExpRuntimeException(ErrorCode.A10014, new String[]{this.getFileName()});
        }

        //取得使用者輸入的請款年月(YYYYMM)
        String invitesFundsYears = (String)params.get("INVITES_FUNDS_YEARS");
        if (StringUtils.isBlank(invitesFundsYears)||StringUtils.length(invitesFundsYears)!=6){
            throw new ExpRuntimeException(ErrorCode.A10007, new String[]{"INVITES_FUNDS_YEARS"});
        }

        //需檢核”請款年月”僅能小於、等於系統日之「年月」，若不符時，顯示《”請款年月”錯誤》訊息，且不可儲存入檔。
        String nowDateStr = DateUtils.getISODateStr(new Date(), "");
        if (invitesFundsYears.compareTo(StringUtils.substring(nowDateStr, 0, 6))>0){
            throw new ExpRuntimeException(ErrorCode.C10053, new String[]{"INVITES_FUNDS_YEARS"});
        }       


        //檢核欲轉入檔案之"請款年月"欄位值，若於費用系統醫檢費暫存檔已有相同請款年月資料，於畫面顯示警示訊息《該請款年月醫檢資料已轉入，不可重覆轉入!!》
        Map<String, Object> criteriaMap = new HashMap<String, Object>();
        criteriaMap.put("invitesFundsYears", invitesFundsYears);
        List<MedicalExpApplDetail> medicalExpAppls = 
            getMedicalExpApplDetailService().findByCriteriaMap(criteriaMap);
        if (!CollectionUtils.isEmpty(medicalExpAppls)){
            throw new ExpRuntimeException(ErrorCode.C10048);
        }

        int totalCount = 0; //轉入總筆數
        BigDecimal totoalAmt = BigDecimal.ZERO;//轉入總金額


        Calendar now = Calendar.getInstance();//系統日期
        User user = getUserService().findByPK(((User)AAUtils.getLoggedInUser()).getId());//登入人員

        ParseStrategy parseStrategy = findParseStrategy("MEDICAL_DETAIL"); //找出醫檢費申請明細Stratery


        // 若外部設定第一筆是抬頭，則跳過不Parse
        if (isFirstLineDataHeader()){
            if (StringUtils.isNotBlank(reader.getFirstLineData())){

                //若第一筆的格式符合匯入格式，要求User確認必須要放抬頭
                String importText = reader.getFirstLineData();
                ImportMedicalExpApplDetailDto dto = null;
                try{
                    dto = (ImportMedicalExpApplDetailDto)parseStrategy.generateImportData(importText);
                }catch(ExpRuntimeException e){
                    if (!e.getErrorCode().equals(ErrorCode.A10013)){
                        throw e;
                    }
                }
                if (null!=dto){
                    throw new ExpRuntimeException(ErrorCode.A10027);
                }
            }
        }else{

            // 更新記錄
            totoalAmt = totoalAmt.add(updateData(reader, reader.getFirstLineData(), invitesFundsYears, parseStrategy, user, now));

            totalCount++;

        }

        // 讀取資料並處理
        while (reader.hasNextLine()) {

            String importText = reader.getNextLine();

            logger.debug(reader.getLineNumber() + " - " + importText);

            if (StringUtils.isNotBlank(importText)){

                // 更新記錄
                totoalAmt = totoalAmt.add(updateData(reader, importText, invitesFundsYears, parseStrategy, user, now));

                totalCount++;
            }
        }

        //轉入筆數為 0時，匯入失敗
        if (totalCount==0){
            throw new ExpRuntimeException(ErrorCode.A10012, new String[]{this.getFileName()});
        }

        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("TOTAL_COUNT", totalCount);
        resultMap.put("TOTAL_AMT", totoalAmt);
        return resultMap;
    }

    /**
     * 更新資料庫的資料s
     * @param reader
     * @param importText 資料列
     * @param invitesFundsYears 請款年月(YYYYMM)
     * @param parseStrategy 內容解析物件
     * @param createUser 建立人員
     * @param createDate 建立日期
     * @return 轉入金額
     */
    private BigDecimal updateData(
            FileReader reader, 
            String importText, 
            String invitesFundsYears, 
            ParseStrategy parseStrategy, 
            User createUser, Calendar createDate){


        ImportMedicalExpApplDetailDto dto = (ImportMedicalExpApplDetailDto)parseStrategy.generateImportData(importText);

        //檢核訊息
        StringBuffer checkMessage = new StringBuffer();

        //各服務中心是否皆有核銷經辦
        Map<String, Boolean> approveMgrMap = getApproveMgrInfo();

        /* 檢核欲轉入檔案之”醫檢年月”欄位值與”請款年月”須在時間差須在三個月內，
         * 例如請款年月為200806(2008/06)可核銷3、4、5月之醫檢費(以月為單位)。
         * 超過三個月之醫檢費，則產生《醫檢年月錯誤》檢核訊息存至原轉入之『醫檢費申請明細』。*/
        int yearMonthSubStract = yearMonthSubstract(dto.getMedicalYears(), invitesFundsYears);       
        if (yearMonthSubStract>3 || yearMonthSubStract<0){
            checkMessage = checkMessage.append(MessageUtils.getAccessor().getMessage("C10040")+" ");
        }        

        /*以醫檢費申請資料的「醫院代號」欄位第一碼做為Key值，去取得暫存的HashMap變數中的Value。
         * 若Value為Boolean.False，則儲存《無核銷權責經辦》至「醫檢費申請資料. 檢核訊息」*/
        Boolean isMgr = approveMgrMap.get(StringUtils.substring(dto.getHospitalId(), 0, 1));
        if (null==isMgr || !isMgr){
            checkMessage = checkMessage.append(MessageUtils.getAccessor().getMessage("C10041")+" ");
        }

        //查出該筆資料所屬醫檢院
        Map<String, Object> criteriaMap = new HashMap<String, Object>();
        criteriaMap.put("code", dto.getHospitalId());
        Hospital hospital = getHospitalService().findByCriteriaMapReturnUnique(criteriaMap);
        if (null==hospital){
            throw new ExpRuntimeException(ErrorCode.C10051, new String[]{dto.getHospitalId()});
        }

        /*
         * 檢核欲轉入檔案之”醫院代號”欄位值，於費用系統之『醫檢院檔』是否有其”帳號”(為匯款時之金融帳號)，
         * 若無，則產生《無匯款帳號》檢核訊息存至『醫檢費申請明細』之檢核訊息欄位。
         */
        if (StringUtils.isBlank(hospital.getAccountNo())){
            checkMessage = checkMessage.append(MessageUtils.getAccessor().getMessage("C10042")+" ");
        }

        /*
         * 以”醫檢院代號”做為key值，檢核欲轉入檔案之”營利事業統一編號”欄位值，
         * 於費用系統之『醫檢院檔』相同”醫院代號”之”醫檢院統編”是否相同，若不同，
         * 則產生《統一編號不符》檢核訊息至原『醫檢費申請明細』之檢核訊息欄位，
         * 若無”營利事業統一編號”，則產生《無統一編號》檢核訊息存至『醫檢費申請明細』之檢核訊息欄位。
         */
        if (StringUtils.isBlank(dto.getCompId())){
            checkMessage = checkMessage.append(MessageUtils.getAccessor().getMessage("C10044")+" ");
        }
        else if (!StringUtils.equals(StringUtils.trim(dto.getCompId()), StringUtils.trim(hospital.getCompId()))){
            checkMessage = checkMessage.append(MessageUtils.getAccessor().getMessage("C10043")+" ");
        }

        /*
         * 檢核欲轉入檔案資料列，”醫院代號”之”醫檢年月”欄位值，於費用系統之『醫檢院檔』該醫院代號之”解約日”
         * (含當月)之醫檢費用不可申請，若醫院於該醫檢年月已解約，則產生《”醫檢院檔於「解約日(醫檢院.解約日)」”已解約》
         * 檢核訊息存至原『醫檢費申請明細』 
         */
        if (null!=hospital.getCancelDate()){
            String cancelDateStr = DateUtils.getISODateStr(hospital.getCancelDate().getTime(), "");
            if (dto.getMedicalYears().compareTo(StringUtils.substring(cancelDateStr, 0, 6))>=0){
                //            if (hospital.isCanceled()){
                String cancelDate=DateUtils.getROCDateStr(hospital.getCancelDate().getTime(), true);//IISI, 2011/01/04 修改民國百年問題 By Eustace
                checkMessage = checkMessage.append(MessageUtils.getAccessor().getMessage("C10045", new String[]{cancelDate})+" ");
            }
        }

        //RE201501570_醫檢及稅務作業修改 CU3178 2015/7/9 START
        //以轉入資料的”扣繳業別”欄位，更新「醫檢院.業別代號」及、「醫檢院檔的」是否代扣財團法人所得”兩個欄位值。
        //this.updateHospital(dto.getWithholdIndustry(), hospital);
        //RE201501570_醫檢及稅務作業修改 CU3178 2015/7/9 END

        MedicalExpApplDetail bo = new MedicalExpApplDetail();
        bo.setHospitalId(dto.getHospitalId());
        bo.setHospitalName(dto.getHospitalName());
        bo.setCompId(dto.getCompId());
        bo.setInvitesFundsYears(invitesFundsYears);//請款年月        
        bo.setMedicalYears(dto.getMedicalYears());//醫檢年月
        bo.setAmt(dto.getAmt());
        bo.setWithholdIndustry(dto.getWithholdIndustry());
        bo.setStampTotalPay(dto.getStampPay());
        bo.setAppliedFormFlag(false);
        bo.setCheckMessage(checkMessage.toString());
        bo.setCreateUser(createUser);
        bo.setCreateDate(createDate);
        //  RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 start
        bo.setStampDutyAmt(dto.getStampDutyAmt());
        //  RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 end

        this.getMedicalExpApplDetailService().create(bo);

        return bo.getAmt();

    }

    /**
     * 取得"服務中心第一碼/是否有核銷權責經辦關係"MAP
     * @return Map<String, Boolean> "服務中心第一碼/是否有核銷權責經辦關係"MAP
     */
    private Map<String, Boolean> getApproveMgrInfo(){

        Map<String, Boolean> results = new HashMap<String, Boolean>();

        List<MedicalExpCostUnitMapping> unitMappingList = getMedicalExpCostUnitMappingService().findAll();

        for (MedicalExpCostUnitMapping unitMapping: unitMappingList){

            List<User> users = getCKindTypeService().findByMiddleTypeCode(
                    MiddleTypeCode.CODE_B00.getCode(), 
                    unitMapping.getDepartment().getCode());

            if (CollectionUtils.isEmpty(users)){
                results.put(unitMapping.getMedicalFirstCode(), false);
            }else{
                results.put(unitMapping.getMedicalFirstCode(), true);
            }
        }        

        return results;
    }


    /**
     * 依轉入資料的”扣繳業別”更新醫檢院檔的”業別代號”、醫檢院檔的”是否代扣財團法人所得”兩個欄位值
     * 
     * @param withholdIndustry 扣繳業別
     * @param hospital 醫檢院
     */
    private void updateHospital(String withholdIndustry, Hospital hospital){

        int withholdValue = Integer.valueOf(StringUtils.trim(withholdIndustry));

        switch (withholdValue){
        case 1: hospital.setIndustryCode(Hospital.INDUSTRY_CODE_COMP);
        hospital.setWithheldLegalPersonIncome(true);
        break;
        case 2: hospital.setIndustryCode(Hospital.INDUSTRY_CODE_COMP);
        hospital.setWithheldLegalPersonIncome(false);
        break;            
        case 3:hospital.setIndustryCode(Hospital.INDUSTRY_CODE_INSURE);
        hospital.setWithheldLegalPersonIncome(true);
        break;            
        case 4:hospital.setIndustryCode(Hospital.INDUSTRY_CODE_INSURE);
        hospital.setWithheldLegalPersonIncome(true);
        break;            
        }

        this.getHospitalService().update(hospital);

    }



    /**
     * 計算兩個年月間，相差的月份
     * @param yearMonth1 年月1(格式:YYYYMM)
     * @param yearMonth2 年月1(格式:YYYYMM)
     * @return 相差的月份
     */
    private int yearMonthSubstract(String yearMonth1, String yearMonth2){
        if (StringUtils.length(yearMonth1)!=6||StringUtils.length(yearMonth2)!=6){
            return 0;
        }

        int result = 0;
        int year1 = Integer.valueOf(StringUtils.substring(yearMonth1, 0, 4));
        int year2 = Integer.valueOf(StringUtils.substring(yearMonth2, 0, 4));
        result = (year2-year1)*12;

        int month1 = Integer.valueOf(StringUtils.substring(yearMonth1, -2));
        int month2 = Integer.valueOf(StringUtils.substring(yearMonth2, -2));

        result = result + (month2-month1);

        return result;
    }



    /**
     * @return the medicalExpApplDetailService
     */
    public MedicalExpApplDetailService getMedicalExpApplDetailService() {
        return medicalExpApplDetailService;
    }

    /**
     * @param medicalExpApplDetailService the medicalExpApplDetailService to set
     */
    public void setMedicalExpApplDetailService(MedicalExpApplDetailService medicalExpApplDetailService) {
        this.medicalExpApplDetailService = medicalExpApplDetailService;
    }

    public HospitalService getHospitalService() {
        return hospitalService;
    }

    public void setHospitalService(HospitalService hospitalService) {
        this.hospitalService = hospitalService;
    }

    public MedicalExpCostUnitMappingService getMedicalExpCostUnitMappingService() {
        return medicalExpCostUnitMappingService;
    }

    public void setMedicalExpCostUnitMappingService(MedicalExpCostUnitMappingService medicalExpCostUnitMappingService) {
        this.medicalExpCostUnitMappingService = medicalExpCostUnitMappingService;
    }

    public CKindTypeService getCKindTypeService() {
        return cKindTypeService;
    }

    public void setCKindTypeService(CKindTypeService kindTypeService) {
        cKindTypeService = kindTypeService;
    }

    public UserService getUserService() {
        return userService;
    }

    public void setUserService(UserService userService) {
        this.userService = userService;
    }







}
