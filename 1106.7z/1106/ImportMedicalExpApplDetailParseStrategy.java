package tw.com.skl.exp.kernel.model6.fileio.strategy.impl;

import java.io.Serializable;
import java.util.Calendar;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import tw.com.skl.exp.kernel.model6.fileio.logic.dto.ImportMedicalExpApplDetailDto;
import tw.com.skl.exp.kernel.model6.fileio.strategy.AbstractParseCSVStrategy;

/**
 * 醫檢費匯入檔內容解析策略類別。
 * 
 * 
 * @author jackson
 */
public class ImportMedicalExpApplDetailParseStrategy extends AbstractParseCSVStrategy {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tw.com.skl.exp.kernel.model6.fileio.stratery.ParseStratery#getDtoInstance
	 * ()
	 */
	public Serializable getDtoInstance() {
		return new ImportMedicalExpApplDetailDto();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tw.com.skl.exp.kernel.model6.fileio.stratery.ParseStratery#checkFormat
	 * (java.lang.String, java.lang.String)
	 */
	public boolean checkFormat(String key, String value) {
        if ("hospitalId".equals(key)) {
            return Pattern.matches("[a-zA-Z0-9]{4}", value);
        }     
        else if ("stampPay".equals(key)) {
            return Pattern.matches("[\\w]", value);
        }       
        else if ("medicalYears".equals(key)) {
            return Pattern.matches("[\\d]{6}", value);
        }       
        else if ("amt".equals(key)) {
            return Pattern.matches("[\\d]{1,}", value);
        }
        else if ("withholdIndustry".equals(key)) {
            return Pattern.matches("[1234]", value);
        }
        
        // RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 start
        else if ("stampDutyAmt".equals(key)) {
            return Pattern.matches("[\\d]{1,}", value);
        }
        //  RE201702268_新增醫檢轉入資料欄位 ec0416 20171106 end
        else {
            
            return true;
        }

    }

}
